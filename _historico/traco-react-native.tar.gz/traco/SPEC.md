# Traço — spec

## Problema
Todo app de notas com IA multiplica na direção errada: completa, resume e consola —
offload do núcleo cognitivo (Kosmyna/MIT 2025: dívida cognitiva). Não existe um bloco
ultra-simples cuja IA multiplique o gesto certo na hora certa sem escrever pelo usuário.

## Tese
O bloco de notas mais simples possível (página escura, teclado, pilha) + IA com
**lista fechada de permissões**:

1. **Rotear** — lê o que o usuário traçou e nomeia o gesto (WOOP, se-então, spec,
   ideia/ZK, desabafo/Pennebaker, destaque do dia). A forma abre com campos VAZIOS.
2. **Travar** — recusa o atalho: afirmação vazia, dump ruminante, plano sem obstáculo,
   mistura de métodos. Uma frase, sem sermão.
3. **Perguntar uma vez** — o próximo campo vazio. A resposta é escrita pelo usuário.
4. **Puxar** — esconde a nota e cobra de memória (retrieval). Depois revela.
5. **Calar.**

## Regra de ferro
A IA NUNCA insere texto na nota. Nunca completa, resume, melhora ou consola.
As formas (labels de campos) são templates do app disparados pela classificação —
estrutura determinística, não prosa do modelo.

## Pronto quando
- [ ] Criar/editar/reabrir notas; abre em <1s; persiste local (AsyncStorage)
- [ ] "quero correr de manhã" + Porteiro → forma WOOP com o texto do usuário no
      primeiro campo e os demais vazios
- [ ] "eu sou um vencedor" + Porteiro → trava com a regra (Wood 2009), sem forma
- [ ] Puxar esconde a nota, usuário escreve de memória, revela comparação

## Não-objetivos (v1)
Chat. Streaks/XP. Ouvinte emocional. Menu de templates. Sync/nuvem. Social.
Resumo de notas. Busca semântica.

## Restrições
- Expo + TypeScript, iOS primeiro
- IA: xAI (Grok), endpoint OpenAI-compatível, chave em EXPO_PUBLIC_XAI_API_KEY
- Porteiro é botão (o usuário aperta) — nunca roda a cada tecla
- Tema escuro único (decisão de produto: a página preta é o produto)

## Casos-limite
Nota vazia + Porteiro → calar (sem chamada). Sem chave de API → aviso curto.
Sem rede → falha silenciosa com aviso. Resposta do modelo fora do JSON → descartar
(calar é melhor que inventar).
