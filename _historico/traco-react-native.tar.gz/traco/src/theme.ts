// Sistema visual — decidido antes dos componentes. Âncora: Apple Notes dark + iOS HIG.
export const color = {
  bg: '#0B0B0D',
  surface: '#161618',
  surfaceHigh: '#1E1E21',
  ink: '#ECECEA',
  inkSoft: '#9A9A96',
  line: '#26262A',
  accent: '#D9A542', // âmbar do Notes
  accentDim: '#8A6A2E',
  trava: '#C4614D',
};

export const space = { xs: 4, s: 8, m: 12, l: 16, xl: 24, xxl: 32 } as const;

export const type = {
  title: { fontSize: 22, fontWeight: '600' as const, color: color.ink },
  body: { fontSize: 17, lineHeight: 26, color: color.ink },
  secondary: { fontSize: 15, color: color.inkSoft },
  label: {
    fontSize: 13,
    fontWeight: '600' as const,
    letterSpacing: 0.8,
    textTransform: 'uppercase' as const,
    color: color.inkSoft,
  },
};

export const radius = { card: 12, control: 10 } as const;
