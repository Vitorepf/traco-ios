// Formas: templates deterministicos do APP (nunca prosa do modelo).
// A forma nasce da palavra do usuário: o texto dele fica em cima, os campos nascem vazios.

export type Gesto = 'woop' | 'se_entao' | 'spec' | 'zk' | 'pennebaker' | 'destaque' | 'nenhum';

export const GESTO_NOME: Record<Gesto, string> = {
  woop: 'WOOP',
  se_entao: 'Se–então',
  spec: 'Spec',
  zk: 'Nota permanente',
  pennebaker: 'Escrita expressiva',
  destaque: 'Destaque do dia',
  nenhum: '—',
};

const SCAFFOLDS: Partial<Record<Gesto, string>> = {
  woop: '\n\n— WOOP —\nResultado (o melhor desfecho):\nObstáculo interno (o SEU hábito/medo):\nSe [obstáculo], então eu:',
  se_entao: '\n\n— Se–então —\nSe (hora / lugar / obstáculo):\nEntão eu (substituto concreto, não "não faço"):',
  spec: '\n\n— Spec —\nProblema:\nPronto quando:\nNão-objetivos:\nRestrições:\nCasos-limite:',
  zk: '\n\n— Nota permanente —\nUma ideia, nas suas palavras:\nLiga a:\nFonte:',
  pennebaker:
    '\n\n— Escrita expressiva —\n15 minutos. Fato E sentimento, sobre o mesmo evento.\nAo terminar: feche. Não releia.',
  destaque: '\n\n— Destaque —\nA única coisa de hoje, primeiro, até acabar:',
};

export function temForma(g: Gesto): boolean {
  return g in SCAFFOLDS;
}

export function aplicarForma(texto: string, g: Gesto): string {
  const s = SCAFFOLDS[g];
  if (!s) return texto;
  if (texto.includes(`— ${GESTO_NOME[g]} —`)) return texto; // uma forma por nota
  return texto.trimEnd() + s;
}
