import { Gesto } from './formas';

export type Veredito = {
  gesto: Gesto;
  trava: string | null; // recusa curta (ex.: afirmação vazia) — quando presente, não abre forma
  pergunta: string | null; // no máximo UMA pergunta: o próximo campo vazio
};

const SYSTEM = `Você é o Porteiro de um bloco de notas. Você NUNCA escreve conteúdo pelo usuário.
Leia o texto e responda APENAS um JSON válido, sem markdown:
{"gesto": "woop"|"se_entao"|"spec"|"zk"|"pennebaker"|"destaque"|"nenhum", "trava": string|null, "pergunta": string|null}

Como classificar o gesto:
- woop: um desejo/meta pessoal ("quero...", "preciso começar...")
- se_entao: hábito que trava num gatilho ("sempre que...", "toda vez que...")
- spec: algo a construir (feature, sistema, projeto de software)
- zk: uma ideia/insight curto que merece virar nota permanente
- pennebaker: desabafo emocional longo sobre um evento
- destaque: lista de tarefas ou "o que fazer hoje"
- nenhum: nada disso; a página segue nua

Quando usar trava (e então gesto="nenhum", pergunta=null):
- Afirmação vazia ("eu sou rico", "eu sou um vencedor") → trava: afirmação piora quem se estima pouco (Wood 2009); escreva POR QUE um valor seu importa.
- Pedido de texto pronto ("escreva para mim", "melhore isso") → trava: aqui a frase é sua; o porteiro não escreve.
- Pedido de ouvinte/terapia ("me escuta", "me console") → trava: quem é a pessoa de verdade que deveria receber isto?
- Mistura de dois métodos na mesma nota → trava: um gesto por sessão.

pergunta: apenas UMA, apontando o próximo campo vazio do gesto identificado
(ex.: woop → "Qual é o obstáculo interno — o seu, não o do mundo?"). Se nada a perguntar, null.
Trava e pergunta são frases curtas em português. Nunca elogie, nunca console, nunca resuma.`;

export async function consultarPorteiro(texto: string): Promise<Veredito | { erro: string }> {
  const key = process.env.EXPO_PUBLIC_XAI_API_KEY;
  if (!key) return { erro: 'Sem chave. Defina EXPO_PUBLIC_XAI_API_KEY no .env.' };
  try {
    const res = await fetch('https://api.x.ai/v1/chat/completions', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${key}` },
      body: JSON.stringify({
        model: 'grok-4-fast-non-reasoning',
        temperature: 0,
        messages: [
          { role: 'system', content: SYSTEM },
          { role: 'user', content: texto.slice(0, 6000) },
        ],
      }),
    });
    if (!res.ok) return { erro: `Porteiro indisponível (${res.status}).` };
    const data = await res.json();
    return parseVeredito(data?.choices?.[0]?.message?.content ?? '');
  } catch {
    return { erro: 'Sem rede. O papel continua funcionando.' };
  }
}

const GESTOS: Gesto[] = ['woop', 'se_entao', 'spec', 'zk', 'pennebaker', 'destaque', 'nenhum'];

// Fora do JSON esperado → calar é melhor que inventar (SPEC: casos-limite).
export function parseVeredito(raw: string): Veredito | { erro: string } {
  try {
    const m = raw.match(/\{[\s\S]*\}/);
    if (!m) return { erro: 'silencio' };
    const j = JSON.parse(m[0]);
    const gesto: Gesto = GESTOS.includes(j.gesto) ? j.gesto : 'nenhum';
    return {
      gesto,
      trava: typeof j.trava === 'string' && j.trava ? j.trava : null,
      pergunta: typeof j.pergunta === 'string' && j.pergunta ? j.pergunta : null,
    };
  } catch {
    return { erro: 'silencio' };
  }
}
