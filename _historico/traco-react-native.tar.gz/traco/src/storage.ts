import AsyncStorage from '@react-native-async-storage/async-storage';

export type Note = {
  id: string;
  text: string;
  createdAt: number;
  updatedAt: number;
};

const KEY = 'traco.notes.v1';

export async function loadNotes(): Promise<Note[]> {
  try {
    const raw = await AsyncStorage.getItem(KEY);
    return raw ? (JSON.parse(raw) as Note[]) : [];
  } catch {
    return [];
  }
}

export async function saveNotes(notes: Note[]): Promise<void> {
  try {
    await AsyncStorage.setItem(KEY, JSON.stringify(notes));
  } catch {
    // ponytail: persistência local best-effort; sem rede de backup na v1
  }
}

export function newNote(): Note {
  const now = Date.now();
  return { id: String(now) + Math.random().toString(36).slice(2, 7), text: '', createdAt: now, updatedAt: now };
}
