import React, { useEffect, useMemo, useRef, useState } from 'react';
import {
  FlatList,
  KeyboardAvoidingView,
  Platform,
  Pressable,
  SafeAreaView,
  StatusBar,
  StyleSheet,
  Text,
  TextInput,
  View,
} from 'react-native';
import { color, radius, space, type } from './src/theme';
import { Note, loadNotes, newNote, saveNotes } from './src/storage';
import { GESTO_NOME, aplicarForma, temForma } from './src/formas';
import { Veredito, consultarPorteiro } from './src/porteiro';

type Puxar = 'off' | 'escrevendo' | 'revelado';

export default function App() {
  const [notes, setNotes] = useState<Note[]>([]);
  const [openId, setOpenId] = useState<string | null>(null);
  const [veredito, setVeredito] = useState<Veredito | null>(null);
  const [erro, setErro] = useState<string | null>(null);
  const [ocupado, setOcupado] = useState(false);
  const [puxar, setPuxar] = useState<Puxar>('off');
  const [memoria, setMemoria] = useState('');
  const saveTimer = useRef<ReturnType<typeof setTimeout> | null>(null);

  useEffect(() => {
    loadNotes().then(setNotes);
  }, []);

  const nota = useMemo(() => notes.find((n) => n.id === openId) ?? null, [notes, openId]);

  function persist(next: Note[]) {
    setNotes(next);
    if (saveTimer.current) clearTimeout(saveTimer.current);
    saveTimer.current = setTimeout(() => saveNotes(next), 400);
  }

  function editar(texto: string) {
    if (!nota) return;
    persist(notes.map((n) => (n.id === nota.id ? { ...n, text: texto, updatedAt: Date.now() } : n)));
  }

  function abrirNova() {
    const n = newNote();
    persist([n, ...notes]);
    abrir(n.id);
  }

  function abrir(id: string) {
    setVeredito(null);
    setErro(null);
    setPuxar('off');
    setMemoria('');
    setOpenId(id);
  }

  function voltar() {
    // nota vazia não vira cartão na pilha
    if (nota && nota.text.trim() === '') persist(notes.filter((n) => n.id !== nota.id));
    abrir('');
    setOpenId(null);
  }

  async function chamarPorteiro() {
    if (!nota || nota.text.trim() === '' || ocupado) return; // nota vazia → calar
    setOcupado(true);
    setErro(null);
    setVeredito(null);
    const r = await consultarPorteiro(nota.text);
    setOcupado(false);
    if ('erro' in r) {
      if (r.erro !== 'silencio') setErro(r.erro);
      return;
    }
    if (r.gesto === 'nenhum' && !r.trava && !r.pergunta) return; // calar
    setVeredito(r);
  }

  function abrirForma() {
    if (!nota || !veredito || veredito.trava || !temForma(veredito.gesto)) return;
    editar(aplicarForma(nota.text, veredito.gesto));
    setVeredito(null);
  }

  // ---------- pilha ----------
  if (!nota) {
    const vivas = notes.filter((n) => n.text.trim() !== '');
    return (
      <SafeAreaView style={s.root}>
        <StatusBar barStyle="light-content" />
        <View style={s.pilhaHeader}>
          <Text style={s.h1}>Traço</Text>
          <Pressable onPress={abrirNova} hitSlop={12} style={s.novaBtn}>
            <Text style={s.novaBtnTxt}>+</Text>
          </Pressable>
        </View>
        {vivas.length === 0 ? (
          <View style={s.vazio}>
            <Text style={s.vazioTxt}>A página espera o traço.</Text>
          </View>
        ) : (
          <FlatList
            data={vivas}
            keyExtractor={(n) => n.id}
            contentContainerStyle={{ paddingHorizontal: space.l }}
            renderItem={({ item }) => {
              const [titulo, ...resto] = item.text.trim().split('\n');
              return (
                <Pressable onPress={() => abrir(item.id)} style={s.row}>
                  <Text style={s.rowTitulo} numberOfLines={1}>
                    {titulo}
                  </Text>
                  <Text style={s.rowSub} numberOfLines={1}>
                    {new Date(item.updatedAt).toLocaleDateString()} · {resto.join(' ').trim() || '—'}
                  </Text>
                </Pressable>
              );
            }}
          />
        )}
      </SafeAreaView>
    );
  }

  // ---------- puxar ----------
  if (puxar !== 'off') {
    return (
      <SafeAreaView style={s.root}>
        <StatusBar barStyle="light-content" />
        <View style={s.editorHeader}>
          <Pressable onPress={() => setPuxar('off')} hitSlop={12}>
            <Text style={s.headerAcao}>Fechar</Text>
          </Pressable>
          <Text style={s.headerLabel}>PUXAR</Text>
          <View style={{ width: 48 }} />
        </View>
        <KeyboardAvoidingView style={{ flex: 1 }} behavior={Platform.OS === 'ios' ? 'padding' : undefined}>
          {puxar === 'escrevendo' ? (
            <>
              <Text style={s.puxarDica}>A nota está escondida. O que estava escrito?</Text>
              <TextInput
                style={s.pagina}
                multiline
                autoFocus
                value={memoria}
                onChangeText={setMemoria}
                keyboardAppearance="dark"
              />
              <Pressable style={s.acaoPrimaria} onPress={() => setPuxar('revelado')}>
                <Text style={s.acaoPrimariaTxt}>Revelar</Text>
              </Pressable>
            </>
          ) : (
            <FlatList
              data={[0]}
              keyExtractor={() => 'cmp'}
              contentContainerStyle={{ padding: space.l, gap: space.l }}
              renderItem={() => (
                <>
                  <Text style={s.cmpLabel}>DE MEMÓRIA</Text>
                  <Text style={s.cmpTexto}>{memoria.trim() || '—'}</Text>
                  <Text style={s.cmpLabel}>A NOTA</Text>
                  <Text style={s.cmpTexto}>{nota.text}</Text>
                </>
              )}
            />
          )}
        </KeyboardAvoidingView>
      </SafeAreaView>
    );
  }

  // ---------- editor ----------
  return (
    <SafeAreaView style={s.root}>
      <StatusBar barStyle="light-content" />
      <View style={s.editorHeader}>
        <Pressable onPress={voltar} hitSlop={12}>
          <Text style={s.headerAcao}>‹ Pilha</Text>
        </Pressable>
        <View style={{ width: 48 }} />
      </View>
      <KeyboardAvoidingView style={{ flex: 1 }} behavior={Platform.OS === 'ios' ? 'padding' : undefined}>
        <TextInput
          style={s.pagina}
          multiline
          autoFocus={nota.text === ''}
          value={nota.text}
          onChangeText={editar}
          keyboardAppearance="dark"
          onFocus={() => setVeredito(null)}
        />

        {erro && <Text style={s.erro}>{erro}</Text>}

        {veredito && (
          <View style={s.cartao}>
            {veredito.trava ? (
              <>
                <Text style={[s.cartaoLabel, { color: color.trava }]}>TRAVA</Text>
                <Text style={s.cartaoTxt}>{veredito.trava}</Text>
              </>
            ) : (
              <>
                <Text style={s.cartaoLabel}>{GESTO_NOME[veredito.gesto].toUpperCase()}</Text>
                {veredito.pergunta && <Text style={s.cartaoTxt}>{veredito.pergunta}</Text>}
                {temForma(veredito.gesto) && (
                  <Pressable onPress={abrirForma} style={s.formaBtn}>
                    <Text style={s.formaBtnTxt}>Abrir forma</Text>
                  </Pressable>
                )}
              </>
            )}
          </View>
        )}

        <View style={s.barra}>
          <Pressable
            onPress={chamarPorteiro}
            style={s.barraBtn}
            disabled={ocupado}
            accessibilityLabel="Porteiro: nomeia o gesto, uma pergunta, nunca escreve"
          >
            <Text style={[s.barraBtnTxt, ocupado && { color: color.accentDim }]}>
              {ocupado ? '…' : 'Porteiro'}
            </Text>
          </Pressable>
          <Pressable
            onPress={() => {
              setMemoria('');
              setPuxar('escrevendo');
            }}
            style={s.barraBtn}
            accessibilityLabel="Puxar: esconde a nota e cobra de memória"
          >
            <Text style={s.barraBtnTxt}>Puxar</Text>
          </Pressable>
        </View>
      </KeyboardAvoidingView>
    </SafeAreaView>
  );
}

const s = StyleSheet.create({
  root: { flex: 1, backgroundColor: color.bg },

  // pilha
  pilhaHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: space.l,
    paddingVertical: space.m,
  },
  h1: { ...type.title, fontSize: 30 },
  novaBtn: {
    width: 36,
    height: 36,
    borderRadius: 18,
    backgroundColor: color.surfaceHigh,
    alignItems: 'center',
    justifyContent: 'center',
  },
  novaBtnTxt: { color: color.accent, fontSize: 24, lineHeight: 27, fontWeight: '400' },
  vazio: { flex: 1, alignItems: 'center', justifyContent: 'center' },
  vazioTxt: { ...type.secondary },
  row: { paddingVertical: space.m, borderBottomWidth: StyleSheet.hairlineWidth, borderBottomColor: color.line },
  rowTitulo: { ...type.body, fontWeight: '600' },
  rowSub: { ...type.secondary, marginTop: 2 },

  // editor
  editorHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: space.l,
    paddingVertical: space.s,
  },
  headerAcao: { color: color.accent, fontSize: 17 },
  headerLabel: { ...type.label },
  pagina: {
    flex: 1,
    ...type.body,
    paddingHorizontal: space.l,
    paddingTop: space.s,
    textAlignVertical: 'top',
  },
  erro: { ...type.secondary, paddingHorizontal: space.l, paddingBottom: space.s },

  cartao: {
    marginHorizontal: space.l,
    marginBottom: space.s,
    padding: space.l,
    borderRadius: radius.card,
    backgroundColor: color.surface,
    gap: space.s,
  },
  cartaoLabel: { ...type.label, color: color.accent },
  cartaoTxt: { ...type.body, fontSize: 16, lineHeight: 23 },
  formaBtn: { alignSelf: 'flex-start', marginTop: space.xs },
  formaBtnTxt: { color: color.accent, fontSize: 16, fontWeight: '600' },

  barra: {
    flexDirection: 'row',
    borderTopWidth: StyleSheet.hairlineWidth,
    borderTopColor: color.line,
  },
  barraBtn: { flex: 1, paddingVertical: space.l, alignItems: 'center' },
  barraBtnTxt: { color: color.accent, fontSize: 16, fontWeight: '600' },

  // puxar
  puxarDica: { ...type.secondary, paddingHorizontal: space.l, paddingBottom: space.s },
  acaoPrimaria: {
    margin: space.l,
    paddingVertical: space.m,
    borderRadius: radius.control,
    backgroundColor: color.surfaceHigh,
    alignItems: 'center',
  },
  acaoPrimariaTxt: { color: color.accent, fontSize: 17, fontWeight: '600' },
  cmpLabel: { ...type.label, color: color.accent },
  cmpTexto: { ...type.body },
});
